import torch
import numpy as np


class NeuralNetwork(torch.nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.fc1 = torch.nn.Linear(2, 4)
        self.fc2 = torch.nn.Linear(4, 1)

    def forward(self, x):
        x = torch.nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class ACO:
    def __init__(self, n_ants, ngen, alpha, beta, rho, Q):
        self.n_ants = n_ants
        self.ngen = ngen
        self.alpha = alpha
        self.beta = beta
        self.rho = rho
        self.Q = Q

    def optimize(self, model, train_inputs, train_labels):
        
        pheromone = {}
        for name, param in model.named_parameters():
            pheromone[name] = torch.ones(param.shape)

    
        best_position = model.state_dict()
        best_fitness = 0

        
        for gen in range(self.ngen):
            for i in range(self.n_ants):
                
                ant_position = model.state_dict()

               
                for name, param in model.named_parameters():
                    probs = pheromone[name].pow(self.alpha) * param.abs().pow(self.beta)
                    probs /= probs.sum()
                    idx = torch.multinomial(probs, 1)[0]
                    ant_position[name] = param[idx]

                
                for name, param in model.named_parameters():
                    model.state_dict()[name].copy_(ant_position[name])

               
                outputs = model(train_inputs)
                loss = torch.nn.functional.mse_loss(outputs, train_labels)
                fitness = 1 / (1 + loss.item())

                
                if fitness > best_fitness:
                    best_position = ant_position
                    best_fitness = fitness

               
                for name, param in model.named_parameters():
                    pheromone[name][param == ant_position[name]] *= 1 + self.Q / fitness

            
            for name, param in model.named_parameters():
                pheromone[name] *= 1 - self.rho

        
        for name, param in model.named_parameters():
            model.state_dict()[name].copy_(best_position[name])

        return model