class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(2, 16)
        self.fc2 = nn.Linear(16, 1)

    def forward(self, x):
        x = torch.sigmoid(self.fc1(x))
        x = self.fc2(x)
        return x


POPULATION_SIZE = 100
MUTATION_RATE = 0.3
GENERATIONS = 100

model = Net()
population = [initialize_chromosome(model) for _ in range(POPULATION_SIZE)]


for generation in range(GENERATIONS):
   
    fitness_scores = [fitness(model, chromosome) for chromosome in population]

    
    new_population = []
    for _ in range(POPULATION_SIZE):
        parent1, parent2 = selection(population)
        child = crossover(parent1, parent2)
        if random.random() < MUTATION_RATE:
            child = mutate(child)
        new_population.append(child)

    
    population = new_population

    
    best_chromosome = max(population, key=fitness)
    with torch.no_grad():
        for i, param in enumerate(model.parameters()):
            param.copy_(best_chromosome[i])