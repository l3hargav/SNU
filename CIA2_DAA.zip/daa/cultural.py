import torch
import numpy as np


class NeuralNetwork(torch.nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.fc1 = torch.nn.Linear(2, 4)
        self.fc2 = torch.nn.Linear(4, 1)

    def forward(self, x):
        x = torch.nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class CulturalAlgorithm:
    def __init__(self, pop_size, ngen, learning_rate):
        self.pop_size = pop_size
        self.ngen = ngen
        self.learning_rate = learning_rate

    def optimize(self, model, train_inputs, train_labels):
        
        population = []
        for i in range(self.pop_size):
            individual = {}
            for name, param in model.named_parameters():
                individual[name] = torch.randn(param.shape)
            population.append(individual)

        
        for gen in range(self.ngen):
            
            fitness = []
            for individual in population:
                model.load_state_dict(individual)
                outputs = model(train_inputs)
                loss = torch.nn.functional.mse_loss(outputs, train_labels)
                fitness.append(1 / (1 + loss.item()))

            
            best_individual = population[np.argmax(fitness)]
            for name, param in model.named_parameters():
                model.state_dict()[name].copy_(best_individual[name])

            
            for i in range(self.pop_size):
                individual = population[i]
                for name, param in model.named_parameters():
                    
                    if np.random.rand() < self.learning_rate:
                        individual[name] = best_individual[name] + torch.randn(param.shape) * 0.1
                    
                    else:
                        individual[name] += torch.randn(param.shape) * 0.1

        return model