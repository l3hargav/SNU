import torch
import numpy as np


class NeuralNetwork(torch.nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.fc1 = torch.nn.Linear(2, 4)
        self.fc2 = torch.nn.Linear(4, 1)

    def forward(self, x):
        x = torch.nn.functional.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class PSO:
    def __init__(self, pop_size, ngen, c1, c2, w_min, w_max):
        self.pop_size = pop_size
        self.ngen = ngen
        self.c1 = c1
        self.c2 = c2
        self.w_min = w_min
        self.w_max = w_max

    def optimize(self, model, train_inputs, train_labels):
        
        swarm = []
        for i in range(self.pop_size):
            particle = {}
            for name, param in model.named_parameters():
                particle[name] = torch.randn(param.shape)
            swarm.append(particle)

        
        best_position = swarm[0]
        best_fitness = 0

        
        for gen in range(self.ngen):
            for i in range(self.pop_size):
                particle = swarm[i]

                
                for name, param in model.named_parameters():
                    r1, r2 = np.random.rand(), np.random.rand()
                    particle[name] = (particle[name] + self.c1 * r1 * (best_position[name] - particle[name])
                                      + self.c2 * r2 * (model.state_dict()[name] - particle[name]))

                
                for name, param in model.named_parameters():
                    particle[name] = torch.clamp(particle[name], -1, 1)

                
                for name, param in model.named_parameters():
                    model.state_dict()[name].copy_(particle[name])

                
                outputs = model(train_inputs)
                loss = torch.nn.functional.mse_loss(outputs, train_labels)
                fitness = 1 / (1 + loss.item())

                
                if fitness > best_fitness:
                    best_position = particle
                    best_fitness = fitness

            
            if best_fitness > fitness:
                for name, param in model.named_parameters():
                    model.state_dict()[name].copy_(best_position[name])

            
            w = self.w_max - (self.w_max - self.w_min) * gen / self.ngen

        return model