import pandas as pd 
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer

data = pd.read_csv("diabetes.csv")
columns = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
data[columns] = data[columns].replace(0, np.nan)


imr = SimpleImputer(missing_values = np.nan, strategy = "mean")
columns = ["Glucose", "BloodPressure", "BMI", "SkinThickness", "Insulin"]
data[columns] = imr.fit_transform(data[columns]) 

x = data.drop("Outcome", axis = 1)
y = data["Outcome"]


clf = LogisticRegression(max_iter=2000)

reg = clf.fit(x, y)



import pickle as pkl

pkl.dump(reg, open("model.pkl","wb"))