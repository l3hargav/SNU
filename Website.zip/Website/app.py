from flask import Flask, render_template, request
import pymysql as pms

username = ''
password = ''
conn = pms.connect(host="localhost", port=3306, password="brjismyname123", db="mlcia")

cur = conn.cursor()

app = Flask(__name__)
import pickle

model = pickle.load(open("model.pkl", "rb"))

@app.route("/")
def main():
    return render_template("index.html")

@app.route("/info", methods=["POST"])
def info():
    global username 
    username = request.form["username"]
    global password 
    password = request.form["password"]
    cur.execute("SELECT * FROM user WHERE username = %s AND password = %s", (username, password))
    record = cur.fetchone()
    if record != None:
        return render_template("info.html", data=info)
    return render_template("error.html",data="Wrong Info")


@app.route("/predict", methods=["POST"])
def predict():
    features = [float(i) for i in (request.form.values())]
    pred = model.predict([features])
    if pred == 1:
        score = "Yes"
    else:
        score = "No"
    return render_template("success.html", score = score)

if __name__ == "__main__":
    app.debug = True
    app.run(host="localhost", port=5000)


