import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import *
from sklearn.model_selection import *
from sklearn.metrics import *
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor
import gc
from sklearn.ensemble import ExtraTreesClassifier, VotingClassifier
from datetime import datetime
import time

train = pd.read_csv('../input/ml-iot/train_ML_IOT.csv')
test = pd.read_csv('../input/ml-iot/test_ML_IOT.csv')

train.drop(["ID"],axis = 1,inplace=True)
test_ID = test["ID"]
test.drop(["ID"],axis = 1,inplace=True)

def remove_duplicate(data):
    print("BEFORE REMOVING DUPLICATES - No. of Rows = ",data.shape[0])
    data.drop_duplicates(keep="first", inplace=True) 
    print("AFTER REMOVING DUPLICATES  - No. of Rows = ",data.shape[0])    
    return data

train = remove_duplicate(train)
test = remove_duplicate(test)

def datetounix1(df):
    # Initialising unixtime list
    unixtime = []
    
    # Running a loop for converting Date to seconds
    for date in df['DateTime']:
        unixtime.append(time.mktime(date.timetuple()))
    
    # Replacing Date with unixtime list
    df['DateTime'] = unixtime
    return(df)

train['DateTime'] = pd.to_datetime(train['DateTime'])
test['DateTime'] = pd.to_datetime(test['DateTime'])
#test.info()

train['Weekday'] = [datetime.weekday(date) for date in train.DateTime]
train['Day'] = [date.day for date in train.DateTime]
train['Time'] = [((date.hour*60+(date.minute))*60)+date.second for date in train.DateTime]
train['Week'] = [date.week for date in train.DateTime]

test['Weekday'] = [datetime.weekday(date) for date in test.DateTime]
test['Day'] = [date.day for date in test.DateTime]
test['Time'] = [((date.hour*60+(date.minute))*60)+date.second for date in test.DateTime]
test['Week'] = [date.week for date in test.DateTime]

#import plotly.express as px
#fig = px.histogram(train, x="Vehicles")
#fig.show()

#fig = px.scatter_matrix(train.iloc[:, 1:])
#fig.show()

#train.head()

train.to_csv('traffic_iot_v3.csv', index=True)


train_features = datetounix1(train.drop(['Vehicles'], axis=1))
test_features = datetounix1(test)

X = train_features  
X_valid = test_features


X = pd.get_dummies(X)
X_valid = pd.get_dummies(X_valid)


y = train['Vehicles'].to_frame()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=512)


final = pd.DataFrame()
final['ID'] = test_ID

# Starting time for time calculations
start_time = time.time()

clf = LGBMRegressor(boosting_type='gbdt',
                    max_depth=6,
                    learning_rate=0.015, 
                    n_estimators=80, 
                    reg_alpha=0.0005,
                    random_state = 512)


clf = clf.fit(X_train, y_train)

y_hat = clf.predict(X_test)

print("The time taken to execute is %s seconds" % (time.time() - start_time))

print("Mean Squared Error: ", mean_squared_error(y_test, y_hat))

# 83.31952543311107
